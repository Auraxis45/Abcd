# MC Glass Panel

A fully automated Minecraft server control panel with a liquid glass UI.

## Run

Requirements: Node.js 18+ and Java 21+ (for current Minecraft versions).

```bash
npm install
npm start
```

Open http://localhost:3000. On first run an admin password is generated, printed in the terminal and saved in `config.json` (or set `ADMIN_PASSWORD=...`).

## What is automated

- Downloads the latest PaperMC server jar if none exists
- Accepts the EULA (by using this you agree to https://aka.ms/MinecraftEULA)
- Starts the server when the panel starts
- Auto-restarts after a crash (stops after 5 crashes in 5 minutes)
- Scheduled backups (cron) with safe `save-off` / `save-all` and old-backup pruning
- Scheduled restarts with in-game countdown warnings
- Scheduled in-game announcements
- Graceful stop on panel shutdown

## Features

Live console over WebSocket, player actions (whitelist, op, kick, ban), backup download/delete, `server.properties` editor, host stats, password change.

## Security

Put the panel behind HTTPS (e.g. Caddy or nginx) before exposing it to the internet. Login attempts are rate limited and sessions expire after 12 hours.
Backup restore is manual: stop the server and unzip a backup into the `server/` folder.
