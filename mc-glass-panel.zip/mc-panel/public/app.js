const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
let token = sessionStorage.getItem('mc_token') || '';
let ws, state = null, uptimeTimer;

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2800);
}
async function api(path, method = 'GET', body) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401 && path !== '/login') { logout(); throw new Error('Session expired'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
const act = async (fn, ok) => { try { await fn(); if (ok) toast(ok); } catch (e) { toast(e.message); } };

/* ---------- auth ---------- */
$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginErr').textContent = '';
  try {
    const r = await api('/login', 'POST', { password: $('#pw').value });
    token = r.token; sessionStorage.setItem('mc_token', token); enter();
  } catch (err) { $('#loginErr').textContent = err.message; }
});
function logout() {
  token = ''; sessionStorage.removeItem('mc_token');
  if (ws) ws.close();
  $('#app').hidden = true; $('#login').hidden = false;
}
$('#logout').onclick = logout;

async function enter() {
  try { await api('/state'); } catch { return logout(); }
  $('#login').hidden = true; $('#app').hidden = false;
  const logs = await api('/logs'); $('#consoleOut').innerHTML = ''; logs.forEach(addLog);
  connect(); loadAll();
}
function connect() {
  if (ws) ws.close();
  ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws?token=${token}`);
  ws.onmessage = (m) => {
    const { type, data } = JSON.parse(m.data);
    if (type === 'status') { state = data; renderState(); }
    if (type === 'log') addLog(data);
  };
  ws.onclose = (e) => { if (token && e.code !== 4001) setTimeout(connect, 2000); };
}

/* ---------- tabs ---------- */
$('#tabs').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  $$('#tabs button').forEach((x) => x.classList.toggle('active', x === b));
  $$('.tab').forEach((t) => t.classList.toggle('active', t.id === 'tab-' + b.dataset.tab));
  loadAll();
});
function loadAll() { loadBackups(); loadSettings(); loadProps(); }

/* ---------- dashboard ---------- */
const fmtBytes = (n) => n > 1e9 ? (n / 1e9).toFixed(1) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : (n / 1e3).toFixed(0) + ' KB';
const ago = (t) => { const s = Math.floor((Date.now() - t) / 1000); return s < 60 ? 'just now' : s < 3600 ? Math.floor(s / 60) + ' min ago' : s < 86400 ? Math.floor(s / 3600) + ' h ago' : Math.floor(s / 86400) + ' d ago'; };
function renderState() {
  if (!state) return;
  $('#statusPill').className = 'pill ' + state.status;
  $('#statusText').textContent = state.status;
  const s = state.status;
  $('[data-act=start]').disabled = !['stopped', 'crashed'].includes(s);
  $('[data-act=stop]').disabled = !['running', 'starting'].includes(s);
  $('[data-act=restart]').disabled = s !== 'running';
  $('#playerCount').textContent = state.players.length;
  $('#playerNames').textContent = state.players.length ? state.players.join(', ') : 'Nobody online';
  $('#onlineList').innerHTML = state.players.length
    ? state.players.map((p) => `<span class="chip" data-name="${p}">${p}</span>`).join('') : '<span class="muted">Nobody online</span>';
  const h = state.host, used = h.totalMem - h.freeMem, pct = Math.round((used / h.totalMem) * 100);
  $('#memPct').textContent = pct + '%'; $('#memBar').style.width = pct + '%';
  $('#memText').textContent = `${fmtBytes(used)} of ${fmtBytes(h.totalMem)}`;
  $('#cpuLoad').textContent = h.load.toFixed(2); $('#cpuText').textContent = `${h.cpus} cores · 1-min load avg`;
  $('#lastBackup').textContent = state.lastBackup ? ago(state.lastBackup.at) : 'None yet';
  $('#jobs').innerHTML = state.jobs.length
    ? state.jobs.map((j) => `<span class="chip">${j.name} · <code>${j.expr}</code></span>`).join('') : '<span class="muted">No scheduled tasks enabled</span>';
  clearInterval(uptimeTimer);
  const tick = () => {
    if (!state.startedAt || !['running', 'starting'].includes(state.status)) return ($('#uptime').textContent = 'Uptime: —');
    const sec = Math.floor((Date.now() - state.startedAt) / 1000);
    $('#uptime').textContent = `Uptime: ${Math.floor(sec / 3600)}h ${Math.floor((sec % 3600) / 60)}m ${sec % 60}s`;
  };
  tick(); uptimeTimer = setInterval(tick, 1000);
}
$$('[data-act]').forEach((b) => (b.onclick = () => {
  if (b.dataset.act === 'kill' && !confirm('Force kill may corrupt world data. Continue?')) return;
  act(() => api('/' + b.dataset.act, 'POST'), b.dataset.act + ' sent');
}));
$('#quickBackup').onclick = () => act(() => api('/backups', 'POST'), 'Backup started');

/* ---------- console ---------- */
function addLog(e) {
  const out = $('#consoleOut');
  const stick = out.scrollTop + out.clientHeight >= out.scrollHeight - 40;
  const d = document.createElement('div');
  d.className = e.kind + (/WARN/.test(e.line) ? ' warn' : '') + (/ERROR|Exception/.test(e.line) ? ' error' : '');
  d.textContent = e.line;
  out.appendChild(d);
  while (out.children.length > 800) out.removeChild(out.firstChild);
  if (stick) out.scrollTop = out.scrollHeight;
}
const history = []; let hi = 0;
$('#cmdForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const v = $('#cmdInput').value.trim(); if (!v) return;
  history.push(v); hi = history.length; $('#cmdInput').value = '';
  act(() => api('/command', 'POST', { command: v }));
});
$('#cmdInput').addEventListener('keydown', (e) => {
  if (e.key === 'ArrowUp' && hi > 0) { $('#cmdInput').value = history[--hi]; e.preventDefault(); }
  if (e.key === 'ArrowDown') { $('#cmdInput').value = history[++hi] || ''; if (hi > history.length) hi = history.length; }
});

/* ---------- players ---------- */
$$('[data-p]').forEach((b) => (b.onclick = () => {
  const name = $('#pName').value.trim();
  act(() => api('/player', 'POST', { action: b.dataset.p, name, reason: $('#pReason').value }), 'Sent');
}));
$('#onlineList').addEventListener('click', (e) => { const c = e.target.closest('[data-name]'); if (c) $('#pName').value = c.dataset.name; });

/* ---------- backups ---------- */
async function loadBackups() {
  try {
    const list = await api('/backups');
    $('#backupList').innerHTML = list.length ? list.map((b) => `
      <div class="item"><div class="name">${b.name}<div class="meta">${fmtBytes(b.size)} · ${ago(b.at)}</div></div>
      <button class="btn small" data-dl="${b.name}">Download</button>
      <button class="btn small danger" data-del="${b.name}">Delete</button></div>`).join('')
      : '<p class="muted">No backups yet.</p>';
  } catch {}
}
$('#newBackup').onclick = () => act(async () => { await api('/backups', 'POST'); setTimeout(loadBackups, 6000); }, 'Backup started');
$('#backupList').addEventListener('click', async (e) => {
  const dl = e.target.dataset.dl, del = e.target.dataset.del;
  if (dl) {
    const r = await fetch('/api/backups/' + dl, { headers: { Authorization: 'Bearer ' + token } });
    if (!r.ok) return toast('Download failed');
    const a = document.createElement('a'); a.href = URL.createObjectURL(await r.blob()); a.download = dl; a.click();
  }
  if (del && confirm('Delete ' + del + '?')) act(async () => { await api('/backups/' + del, 'DELETE'); loadBackups(); }, 'Deleted');
});

/* ---------- settings ---------- */
async function loadSettings() {
  try {
    const s = await api('/settings');
    $$('#settingsForm [name]').forEach((el) => {
      if (el.name === 'newPassword') return;
      if (el.type === 'checkbox') el.checked = !!s[el.name]; else el.value = s[el.name] ?? '';
    });
  } catch {}
}
$('#settingsForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const body = {};
  $$('#settingsForm [name]').forEach((el) => { body[el.name] = el.type === 'checkbox' ? el.checked : el.type === 'number' ? +el.value : el.value; });
  act(async () => { await api('/settings', 'PUT', body); $('#settingsForm [name=newPassword]').value = ''; }, 'Settings saved');
});

/* ---------- properties ---------- */
async function loadProps() {
  try {
    const p = await api('/properties'); const keys = Object.keys(p);
    $('#propsNote').hidden = keys.length > 0;
    $('#propsList').innerHTML = keys.map((k) => `<label>${k}<input data-key="${k}" value="${String(p[k]).replace(/"/g, '&quot;')}"></label>`).join('');
  } catch {}
}
$('#saveProps').onclick = () => {
  const body = {}; $$('#propsList [data-key]').forEach((i) => (body[i.dataset.key] = i.value));
  act(() => api('/properties', 'PUT', body), 'Saved — restart to apply');
};

if (token) enter();
