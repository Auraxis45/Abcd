// MC Glass Panel — automated Minecraft server control panel (backend)
const express = require('express');
const http = require('http');
const https = require('https');
const { WebSocketServer } = require('ws');
const cron = require('node-cron');
const archiver = require('archiver');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, 'config.json');
const BACKUP_DIR = path.join(ROOT, 'backups');

// ---------- config ----------
const DEFAULTS = {
  port: 3000,
  adminPassword: '',
  serverDir: 'server',
  jarFile: 'server.jar',
  javaPath: 'java',
  memory: '2G',
  minecraftVersion: 'latest',
  autoStartOnBoot: true,
  autoRestartOnCrash: true,
  backupCron: '0 */6 * * *',
  backupEnabled: true,
  maxBackups: 10,
  restartCron: '0 5 * * *',
  restartEnabled: false,
  restartWarnSeconds: 60,
  announceCron: '',
  announceMessage: 'Join our Discord!',
};
let config = { ...DEFAULTS };
function loadConfig() {
  if (fs.existsSync(CONFIG_PATH)) {
    try { config = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')) }; } catch (e) { console.error('Bad config.json', e.message); }
  }
  if (process.env.ADMIN_PASSWORD) config.adminPassword = process.env.ADMIN_PASSWORD;
  if (!config.adminPassword) {
    config.adminPassword = crypto.randomBytes(6).toString('hex');
    console.log(`\n  Generated admin password: ${config.adminPassword}\n  (saved in config.json)\n`);
  }
  saveConfig();
}
function saveConfig() { fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2)); }
loadConfig();
const serverPath = () => path.resolve(ROOT, config.serverDir);
fs.mkdirSync(serverPath(), { recursive: true });
fs.mkdirSync(BACKUP_DIR, { recursive: true });

// ---------- state / ws ----------
const state = {
  status: 'stopped', // stopped | downloading | starting | running | stopping | crashed
  startedAt: null,
  players: new Set(),
  logs: [],
  crashes: [],
  manualStop: true,
  lastBackup: null,
  jobs: [],
};
const clients = new Set();
function broadcast(type, data) {
  const msg = JSON.stringify({ type, data });
  for (const c of clients) if (c.readyState === 1) c.send(msg);
}
function log(line, kind = 'server') {
  const entry = { t: Date.now(), kind, line };
  state.logs.push(entry);
  if (state.logs.length > 1000) state.logs.shift();
  broadcast('log', entry);
}
function setStatus(s) { state.status = s; broadcast('status', publicState()); }
function publicState() {
  return {
    status: state.status,
    startedAt: state.startedAt,
    players: [...state.players],
    lastBackup: state.lastBackup,
    jobs: state.jobs,
    host: {
      load: os.loadavg()[0],
      cpus: os.cpus().length,
      totalMem: os.totalmem(),
      freeMem: os.freemem(),
      uptime: os.uptime(),
    },
  };
}

// ---------- helpers ----------
function getJSON(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'mc-glass-panel/1.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return resolve(getJSON(res.headers.location));
      let b = '';
      res.on('data', (d) => (b += d));
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(e); } });
    }).on('error', reject);
  });
}
function download(url, dest) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'mc-glass-panel/1.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return resolve(download(res.headers.location, dest));
      if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode));
      const f = fs.createWriteStream(dest);
      res.pipe(f);
      f.on('finish', () => f.close(resolve));
      f.on('error', reject);
    }).on('error', reject);
  });
}
async function ensureJar() {
  const jar = path.join(serverPath(), config.jarFile);
  if (fs.existsSync(jar)) return;
  setStatus('downloading');
  log('No server jar found. Downloading latest PaperMC build...', 'panel');
  const proj = await getJSON('https://api.papermc.io/v2/projects/paper');
  const version = config.minecraftVersion === 'latest' ? proj.versions[proj.versions.length - 1] : config.minecraftVersion;
  const builds = await getJSON(`https://api.papermc.io/v2/projects/paper/versions/${version}/builds`);
  const build = builds.builds[builds.builds.length - 1];
  const name = build.downloads.application.name;
  log(`Downloading Paper ${version} build ${build.build}...`, 'panel');
  await download(`https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${build.build}/downloads/${name}`, jar);
  log('Download complete.', 'panel');
}
function ensureEula() {
  const p = path.join(serverPath(), 'eula.txt');
  fs.writeFileSync(p, '# Auto-accepted by MC Glass Panel. You agree to https://aka.ms/MinecraftEULA by using this panel.\neula=true\n');
}

// ---------- process manager ----------
let proc = null;
let stopTimer = null;
async function startServer() {
  if (proc || ['starting', 'downloading', 'stopping'].includes(state.status)) throw new Error('Server is busy: ' + state.status);
  state.manualStop = false;
  try { await ensureJar(); } catch (e) { log('Jar download failed: ' + e.message, 'panel'); setStatus('stopped'); throw e; }
  ensureEula();
  setStatus('starting');
  const args = [`-Xms${config.memory}`, `-Xmx${config.memory}`, '-jar', config.jarFile, 'nogui'];
  log(`$ ${config.javaPath} ${args.join(' ')}`, 'panel');
  try {
    proc = spawn(config.javaPath, args, { cwd: serverPath() });
  } catch (e) { setStatus('stopped'); throw e; }
  state.players.clear();
  state.startedAt = Date.now();
  const onData = (buf) => {
    for (const line of buf.toString().split(/\r?\n/)) {
      if (!line.trim()) continue;
      log(line);
      if (/Done \(.*\)! For help/.test(line)) setStatus('running');
      let m;
      if ((m = line.match(/: (\w{1,16}) joined the game/))) { state.players.add(m[1]); broadcast('status', publicState()); }
      if ((m = line.match(/: (\w{1,16}) left the game/))) { state.players.delete(m[1]); broadcast('status', publicState()); }
    }
  };
  proc.stdout.on('data', onData);
  proc.stderr.on('data', onData);
  proc.on('error', (e) => { log('Failed to launch Java: ' + e.message + ' (is Java 21+ installed?)', 'panel'); proc = null; setStatus('stopped'); });
  proc.on('close', (code) => {
    clearTimeout(stopTimer);
    proc = null;
    state.startedAt = null;
    state.players.clear();
    log(`Server process exited with code ${code}`, 'panel');
    if (!state.manualStop && config.autoRestartOnCrash) {
      const now = Date.now();
      state.crashes = state.crashes.filter((t) => now - t < 5 * 60 * 1000);
      state.crashes.push(now);
      if (state.crashes.length > 5) {
        log('Crash loop detected (5 crashes in 5 min). Auto-restart disabled until you start manually.', 'panel');
        setStatus('crashed');
        return;
      }
      setStatus('crashed');
      log('Unexpected exit. Auto-restarting in 5 seconds...', 'panel');
      setTimeout(() => { if (!proc && !state.manualStop) startServer().catch(() => {}); }, 5000);
    } else {
      setStatus('stopped');
    }
  });
}
function sendCommand(cmd) {
  if (!proc || !proc.stdin.writable) throw new Error('Server is not running');
  proc.stdin.write(cmd.replace(/[\r\n]/g, ' ') + '\n');
  log('> ' + cmd, 'cmd');
}
function stopServer(manual = true) {
  return new Promise((resolve) => {
    if (!proc) { setStatus('stopped'); return resolve(); }
    state.manualStop = manual;
    setStatus('stopping');
    const p = proc;
    p.once('close', () => resolve());
    try { sendCommand('stop'); } catch (e) { p.kill(); }
    stopTimer = setTimeout(() => { log('Graceful stop timed out, killing process.', 'panel'); p.kill('SIGKILL'); }, 45000);
  });
}
async function restartServer(warn = false) {
  if (warn && proc && state.status === 'running') {
    const s = config.restartWarnSeconds;
    try {
      sendCommand(`say Server restarting in ${s} seconds!`);
      await new Promise((r) => setTimeout(r, Math.max(0, s - 10) * 1000));
      sendCommand('say Server restarting in 10 seconds!');
      await new Promise((r) => setTimeout(r, Math.min(10, s) * 1000));
    } catch (e) {}
  }
  await stopServer(true);
  await startServer();
}

// ---------- backups ----------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let backingUp = false;
async function makeBackup(label = 'auto') {
  if (backingUp) throw new Error('A backup is already running');
  backingUp = true;
  const live = proc && state.status === 'running';
  try {
    if (live) { sendCommand('save-off'); sendCommand('save-all flush'); await sleep(4000); }
    const name = `backup-${label}-${new Date().toISOString().replace(/[:.]/g, '-')}.zip`;
    const out = fs.createWriteStream(path.join(BACKUP_DIR, name));
    const zip = archiver('zip', { zlib: { level: 6 } });
    const done = new Promise((res, rej) => { out.on('close', res); zip.on('error', rej); });
    zip.pipe(out);
    zip.glob('**/*', { cwd: serverPath(), ignore: ['logs/**', 'cache/**', '*.jar', 'session.lock', '**/session.lock'] });
    await zip.finalize();
    await done;
    state.lastBackup = { name, at: Date.now() };
    log(`Backup created: ${name}`, 'panel');
    pruneBackups();
    broadcast('status', publicState());
    return name;
  } finally {
    if (live && proc) try { sendCommand('save-on'); } catch (e) {}
    backingUp = false;
  }
}
function listBackups() {
  return fs.readdirSync(BACKUP_DIR).filter((f) => f.endsWith('.zip')).map((f) => {
    const s = fs.statSync(path.join(BACKUP_DIR, f));
    return { name: f, size: s.size, at: s.mtimeMs };
  }).sort((a, b) => b.at - a.at);
}
function pruneBackups() {
  const all = listBackups();
  for (const b of all.slice(config.maxBackups)) fs.unlinkSync(path.join(BACKUP_DIR, b.name));
}

// ---------- scheduler ----------
let tasks = [];
function schedule() {
  tasks.forEach((t) => t.stop());
  tasks = [];
  state.jobs = [];
  const add = (name, expr, enabled, fn) => {
    if (!enabled || !expr) return;
    if (!cron.validate(expr)) { log(`Invalid cron for ${name}: ${expr}`, 'panel'); return; }
    tasks.push(cron.schedule(expr, () => fn().catch((e) => log(`${name} failed: ${e.message}`, 'panel'))));
    state.jobs.push({ name, expr });
  };
  add('Auto backup', config.backupCron, config.backupEnabled, () => makeBackup('auto'));
  add('Scheduled restart', config.restartCron, config.restartEnabled, () => restartServer(true));
  add('Announcement', config.announceCron, !!config.announceCron, async () => sendCommand('say ' + config.announceMessage));
  broadcast('status', publicState());
}

// ---------- http api ----------
const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(ROOT, 'public')));

const tokens = new Map(); // token -> expiry
const attempts = new Map();
function newToken() { const t = crypto.randomBytes(24).toString('hex'); tokens.set(t, Date.now() + 12 * 3600 * 1000); return t; }
function validToken(t) { const e = tokens.get(t); if (!e) return false; if (e < Date.now()) { tokens.delete(t); return false; } return true; }
function safeEq(a, b) { const ha = crypto.createHash('sha256').update(a).digest(), hb = crypto.createHash('sha256').update(b).digest(); return crypto.timingSafeEqual(ha, hb); }

app.post('/api/login', (req, res) => {
  const ip = req.ip;
  const a = attempts.get(ip) || { n: 0, t: Date.now() };
  if (Date.now() - a.t > 10 * 60 * 1000) { a.n = 0; a.t = Date.now(); }
  if (a.n >= 8) return res.status(429).json({ error: 'Too many attempts. Try again later.' });
  if (typeof req.body.password === 'string' && safeEq(req.body.password, config.adminPassword)) {
    attempts.delete(ip);
    return res.json({ token: newToken() });
  }
  a.n++; attempts.set(ip, a);
  res.status(401).json({ error: 'Wrong password' });
});

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : req.query.token;
  if (!validToken(t)) return res.status(401).json({ error: 'Unauthorized' });
  next();
}
const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch((e) => res.status(400).json({ error: e.message }));

app.get('/api/state', auth, (req, res) => res.json(publicState()));
app.post('/api/start', auth, wrap(async (req, res) => { startServer().catch((e) => log(e.message, 'panel')); res.json({ ok: true }); }));
app.post('/api/stop', auth, wrap(async (req, res) => { stopServer(true); res.json({ ok: true }); }));
app.post('/api/restart', auth, wrap(async (req, res) => { restartServer(false).catch((e) => log(e.message, 'panel')); res.json({ ok: true }); }));
app.post('/api/kill', auth, wrap(async (req, res) => { if (proc) { state.manualStop = true; proc.kill('SIGKILL'); } res.json({ ok: true }); }));
app.post('/api/command', auth, wrap(async (req, res) => {
  const cmd = String(req.body.command || '').trim();
  if (!cmd) throw new Error('Empty command');
  sendCommand(cmd.replace(/^\//, ''));
  res.json({ ok: true });
}));
app.post('/api/player', auth, wrap(async (req, res) => {
  const { action, name, reason } = req.body;
  if (!/^\w{1,16}$/.test(name || '')) throw new Error('Invalid player name');
  const map = {
    op: `op ${name}`, deop: `deop ${name}`, kick: `kick ${name} ${reason || ''}`.trim(),
    ban: `ban ${name} ${reason || ''}`.trim(), pardon: `pardon ${name}`,
    whitelist_add: `whitelist add ${name}`, whitelist_remove: `whitelist remove ${name}`,
  };
  if (!map[action]) throw new Error('Unknown action');
  sendCommand(map[action]);
  res.json({ ok: true });
}));
app.get('/api/logs', auth, (req, res) => res.json(state.logs.slice(-300)));

app.get('/api/backups', auth, (req, res) => res.json(listBackups()));
app.post('/api/backups', auth, wrap(async (req, res) => { makeBackup('manual').catch((e) => log('Backup failed: ' + e.message, 'panel')); res.json({ ok: true }); }));
function backupFile(name) {
  if (!/^backup-[\w.\-]+\.zip$/.test(name)) throw new Error('Bad name');
  const p = path.join(BACKUP_DIR, name);
  if (!fs.existsSync(p)) throw new Error('Not found');
  return p;
}
app.get('/api/backups/:name', auth, (req, res) => { try { res.download(backupFile(req.params.name)); } catch (e) { res.status(404).json({ error: e.message }); } });
app.delete('/api/backups/:name', auth, wrap(async (req, res) => { fs.unlinkSync(backupFile(req.params.name)); res.json({ ok: true }); }));

app.get('/api/settings', auth, (req, res) => { const { adminPassword, ...rest } = config; res.json(rest); });
app.put('/api/settings', auth, wrap(async (req, res) => {
  const b = req.body, next = { ...config };
  const str = ['javaPath', 'memory', 'minecraftVersion', 'backupCron', 'restartCron', 'announceCron', 'announceMessage'];
  const bool = ['autoStartOnBoot', 'autoRestartOnCrash', 'backupEnabled', 'restartEnabled'];
  const num = ['maxBackups', 'restartWarnSeconds'];
  for (const k of str) if (typeof b[k] === 'string') next[k] = b[k].slice(0, 200);
  for (const k of bool) if (typeof b[k] === 'boolean') next[k] = b[k];
  for (const k of num) if (Number.isFinite(+b[k])) next[k] = Math.max(1, Math.min(1000, +b[k]));
  if (!/^\d+[MG]$/i.test(next.memory)) throw new Error('Memory must look like 2G or 2048M');
  if (/[;&|`$\s]/.test(next.javaPath)) throw new Error('Invalid java path');
  for (const k of ['backupCron', 'restartCron', 'announceCron']) if (next[k] && !cron.validate(next[k])) throw new Error(`Invalid cron expression for ${k}`);
  if (typeof b.newPassword === 'string' && b.newPassword.length >= 6) next.adminPassword = b.newPassword;
  config = next; saveConfig(); schedule();
  res.json({ ok: true });
}));

const propsPath = () => path.join(serverPath(), 'server.properties');
app.get('/api/properties', auth, wrap(async (req, res) => {
  if (!fs.existsSync(propsPath())) return res.json({});
  const out = {};
  for (const l of fs.readFileSync(propsPath(), 'utf8').split(/\r?\n/)) {
    if (!l || l.startsWith('#')) continue;
    const i = l.indexOf('=');
    if (i > 0) out[l.slice(0, i)] = l.slice(i + 1);
  }
  res.json(out);
}));
app.put('/api/properties', auth, wrap(async (req, res) => {
  const lines = ['#Edited by MC Glass Panel'];
  for (const [k, v] of Object.entries(req.body || {})) {
    if (!/^[\w.\-]+$/.test(k)) continue;
    lines.push(`${k}=${String(v).replace(/[\r\n]/g, '')}`);
  }
  fs.writeFileSync(propsPath(), lines.join('\n') + '\n');
  res.json({ ok: true, note: 'Restart the server to apply.' });
}));

// ---------- boot ----------
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
wss.on('connection', (ws, req) => {
  const token = new URL(req.url, 'http://x').searchParams.get('token');
  if (!validToken(token)) return ws.close(4001, 'unauthorized');
  clients.add(ws);
  ws.send(JSON.stringify({ type: 'status', data: publicState() }));
  ws.on('close', () => clients.delete(ws));
});
setInterval(() => { if (clients.size) broadcast('status', publicState()); }, 5000);

server.listen(config.port, () => {
  console.log(`MC Glass Panel running at http://localhost:${config.port}`);
  schedule();
  if (config.autoStartOnBoot) startServer().catch((e) => log('Auto-start failed: ' + e.message, 'panel'));
});

async function shutdown() {
  console.log('Shutting down...');
  await stopServer(true).catch(() => {});
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
